package com.tausif.sambchecker

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.animation.DecelerateInterpolator
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.cardview.widget.CardView
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.tausif.sambchecker.databinding.ActivityHistoryBinding
import com.tausif.sambchecker.model.BatteryRecord
import com.tausif.sambchecker.util.HistoryManager

class HistoryActivity : AppCompatActivity() {

    private lateinit var binding: ActivityHistoryBinding
    private val records = mutableListOf<BatteryRecord>()
    private lateinit var adapter: HistoryAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityHistoryBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupRecyclerView()
        loadHistory()
        setupClickListeners()
    }

    private fun setupRecyclerView() {
        adapter = HistoryAdapter(records) { record ->
            val intent = Intent(this, BatteryResultActivity::class.java)
            intent.putExtra(BatteryResultActivity.EXTRA_RECORD_ID, record.id)
            startActivity(intent)
            overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left)
        }
        binding.recyclerHistory.layoutManager = LinearLayoutManager(this)
        binding.recyclerHistory.adapter = adapter
    }

    private fun loadHistory() {
        val loaded = HistoryManager.getRecords(this)
        records.clear()
        records.addAll(loaded)
        adapter.notifyDataSetChanged()

        if (records.isEmpty()) {
            binding.layoutEmpty.visibility = View.VISIBLE
            binding.recyclerHistory.visibility = View.GONE
        } else {
            binding.layoutEmpty.visibility = View.GONE
            binding.recyclerHistory.visibility = View.VISIBLE
            animateList()
        }
    }

    private fun animateList() {
        // Animate RecyclerView items from bottom
        binding.recyclerHistory.addOnChildAttachStateChangeListener(object :
            RecyclerView.OnChildAttachStateChangeListener {
            override fun onChildViewAttachedToWindow(view: View) {
                view.alpha = 0f
                view.translationY = 40f
                view.animate()
                    .alpha(1f)
                    .translationY(0f)
                    .setDuration(400)
                    .setInterpolator(DecelerateInterpolator(2f))
                    .start()
            }
            override fun onChildViewDetachedFromWindow(view: View) {}
        })
    }

    private fun setupClickListeners() {
        binding.btnBack.setOnClickListener { onBackPressedDispatcher.onBackPressed() }
        binding.btnClear.setOnClickListener { showClearConfirmation() }
    }

    private fun showClearConfirmation() {
        AlertDialog.Builder(this, R.style.SamDialog)
            .setTitle("Clear History")
            .setMessage("This will delete all ${records.size} battery check records. This cannot be undone.")
            .setPositiveButton("Clear All") { _, _ ->
                HistoryManager.clearHistory(this)
                loadHistory()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    override fun finish() {
        super.finish()
        overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right)
    }

    // ─── Adapter ─────────────────────────────────────────────────────────────

    inner class HistoryAdapter(
        private val items: List<BatteryRecord>,
        private val onClick: (BatteryRecord) -> Unit
    ) : RecyclerView.Adapter<HistoryAdapter.ViewHolder>() {

        inner class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
            val tvHealth: TextView = view.findViewById(R.id.tvHistoryHealth)
            val tvDevice: TextView = view.findViewById(R.id.tvHistoryDevice)
            val tvDate: TextView = view.findViewById(R.id.tvHistoryDate)
            val tvStatus: TextView = view.findViewById(R.id.tvHistoryStatus)
            val card: CardView = view.findViewById(R.id.cardHistory)
            val tvRank: TextView = view.findViewById(R.id.tvHistoryRank)
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
            val v = LayoutInflater.from(parent.context)
                .inflate(R.layout.item_history, parent, false)
            return ViewHolder(v)
        }

        override fun onBindViewHolder(holder: ViewHolder, position: Int) {
            val r = items[position]
            val status = r.getHealthStatus()

            holder.tvHealth.text = "${r.batteryHealth}%"
            holder.tvDevice.text = r.deviceModel
            holder.tvDate.text = r.getFormattedDate()
            holder.tvStatus.text = "${status.emoji} ${status.label}"
            holder.tvRank.text = if (position == 0) "Latest" else "#${position + 1}"

            val color = when {
                r.batteryHealth >= 80 -> ContextCompat.getColor(holder.itemView.context, R.color.health_excellent)
                r.batteryHealth >= 60 -> ContextCompat.getColor(holder.itemView.context, R.color.health_good)
                r.batteryHealth >= 40 -> ContextCompat.getColor(holder.itemView.context, R.color.health_fair)
                r.batteryHealth >= 20 -> ContextCompat.getColor(holder.itemView.context, R.color.health_poor)
                else -> ContextCompat.getColor(holder.itemView.context, R.color.health_critical)
            }
            holder.tvHealth.setTextColor(color)

            holder.card.setOnClickListener { onClick(r) }
        }

        override fun getItemCount() = items.size
    }
}
