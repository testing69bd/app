package com.tausif.sambchecker.util

import android.content.Context
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.tausif.sambchecker.model.BatteryRecord

object HistoryManager {

    private const val PREF_NAME = "sambchecker_history"
    private const val KEY_RECORDS = "battery_records"
    private const val MAX_RECORDS = 20

    private val gson = Gson()

    fun saveRecord(context: Context, record: BatteryRecord) {
        val records = getRecords(context).toMutableList()
        records.add(0, record) // Add to front
        if (records.size > MAX_RECORDS) {
            records.removeAt(records.size - 1)
        }
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        prefs.edit().putString(KEY_RECORDS, gson.toJson(records)).apply()
    }

    fun getRecords(context: Context): List<BatteryRecord> {
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        val json = prefs.getString(KEY_RECORDS, null) ?: return emptyList()
        return try {
            val type = object : TypeToken<List<BatteryRecord>>() {}.type
            gson.fromJson(json, type) ?: emptyList()
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun clearHistory(context: Context) {
        context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
            .edit().clear().apply()
    }

    fun getLastRecord(context: Context): BatteryRecord? {
        return getRecords(context).firstOrNull()
    }
}
