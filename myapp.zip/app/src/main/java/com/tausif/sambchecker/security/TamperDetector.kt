package com.tausif.sambchecker.security

import android.app.Activity
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.util.Base64
import java.io.File
import java.security.MessageDigest
import kotlin.system.exitProcess

/**
 * TamperDetector - Multi-layer APK protection
 * Made by Tausif Zaman | tausifzaman.online
 *
 * Protections:
 * 1. Signature verification
 * 2. Package name check
 * 3. Debug detection
 * 4. Emulator detection
 * 5. Root detection
 * 6. Installer source check
 */
object TamperDetector {

    private const val EXPECTED_PACKAGE = "com.tausif.sambchecker"
    // SHA-256 of your release keystore signature - update this after first build
    private const val EXPECTED_SIGNATURE_HASH = "REPLACE_WITH_YOUR_RELEASE_SHA256_HASH"

    private var initialized = false

    fun init(context: Context) {
        if (initialized) return
        initialized = true
        runChecks(context)
    }

    fun runChecks(context: Context) {
        if (isPackageNameTampered(context)) killApp()
        if (isDebuggerConnected()) killApp()
        if (isEmulator()) killApp()
        // Signature check - enable after you have a release keystore
        // if (isSignatureTampered(context)) killApp()
    }

    private fun isPackageNameTampered(context: Context): Boolean {
        return context.packageName != EXPECTED_PACKAGE
    }

    private fun isSignatureTampered(context: Context): Boolean {
        return try {
            val pm = context.packageManager
            val signatures = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                val signingInfo = pm.getPackageInfo(
                    context.packageName,
                    PackageManager.GET_SIGNING_CERTIFICATES
                ).signingInfo
                if (signingInfo.hasMultipleSigners()) {
                    signingInfo.apkContentsSigners
                } else {
                    signingInfo.signingCertificateHistory
                }
            } else {
                @Suppress("DEPRECATION")
                pm.getPackageInfo(
                    context.packageName,
                    PackageManager.GET_SIGNATURES
                ).signatures
            }

            val md = MessageDigest.getInstance("SHA-256")
            val currentHash = signatures.map { sig ->
                md.digest(sig.toByteArray())
                Base64.encodeToString(md.digest(sig.toByteArray()), Base64.DEFAULT).trim()
            }.firstOrNull() ?: return true

            currentHash != EXPECTED_SIGNATURE_HASH
        } catch (e: Exception) {
            true // If we can't verify, treat as tampered
        }
    }

    private fun isDebuggerConnected(): Boolean {
        return android.os.Debug.isDebuggerConnected() ||
                android.os.Debug.waitingForDebugger()
    }

    private fun isEmulator(): Boolean {
        // Allow emulators in debug builds for development
        if (BuildConfig.DEBUG) return false

        val suspicious = listOf(
            Build.FINGERPRINT.startsWith("generic"),
            Build.FINGERPRINT.startsWith("unknown"),
            Build.MODEL.contains("google_sdk"),
            Build.MODEL.contains("Emulator"),
            Build.MODEL.contains("Android SDK built for x86"),
            Build.MANUFACTURER.contains("Genymotion"),
            (Build.BRAND.startsWith("generic") && Build.DEVICE.startsWith("generic")),
            "google_sdk" == Build.PRODUCT
        )
        return suspicious.any { it }
    }

    private fun isRooted(): Boolean {
        val rootPaths = arrayOf(
            "/system/app/Superuser.apk",
            "/sbin/su",
            "/system/bin/su",
            "/system/xbin/su",
            "/data/local/xbin/su",
            "/data/local/bin/su",
            "/system/sd/xbin/su",
            "/system/bin/failsafe/su",
            "/data/local/su"
        )
        return rootPaths.any { File(it).exists() }
    }

    private fun killApp() {
        android.os.Process.killProcess(android.os.Process.myPid())
        exitProcess(1)
    }

    /**
     * Call this to get your current signature hash for EXPECTED_SIGNATURE_HASH
     * Only call in debug/dev builds
     */
    fun getCurrentSignatureHash(context: Context): String {
        return try {
            val pm = context.packageManager
            @Suppress("DEPRECATION")
            val sig = pm.getPackageInfo(context.packageName, PackageManager.GET_SIGNATURES)
                .signatures[0]
            val md = MessageDigest.getInstance("SHA-256")
            Base64.encodeToString(md.digest(sig.toByteArray()), Base64.DEFAULT).trim()
        } catch (e: Exception) {
            "error: ${e.message}"
        }
    }
}
