package com.tausif.sambchecker.model

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class BatteryRecord(
    val id: Long = System.currentTimeMillis(),
    val batteryHealth: Int,           // mSavedBatteryAsoc value (%)
    val deviceModel: String,
    val dumpFileName: String,
    val timestamp: Long = System.currentTimeMillis(),
    val batteryCapacity: String? = null,
    val cycleCount: Int? = null,
    val temperature: String? = null,
    val voltage: String? = null,
    val chargeFull: String? = null,
    val chargeNow: String? = null,
    val additionalInfo: Map<String, String> = emptyMap()
) {
    fun getFormattedDate(): String {
        val sdf = SimpleDateFormat("MMM dd, yyyy  hh:mm a", Locale.getDefault())
        return sdf.format(Date(timestamp))
    }

    fun getHealthStatus(): HealthStatus {
        return when {
            batteryHealth >= 80 -> HealthStatus.EXCELLENT
            batteryHealth >= 60 -> HealthStatus.GOOD
            batteryHealth >= 40 -> HealthStatus.FAIR
            batteryHealth >= 20 -> HealthStatus.POOR
            else -> HealthStatus.CRITICAL
        }
    }
}

enum class HealthStatus(val label: String, val colorResId: String, val emoji: String) {
    EXCELLENT("Excellent", "#00E676", "🔋"),
    GOOD("Good", "#76FF03", "✅"),
    FAIR("Fair", "#FFAB00", "⚠️"),
    POOR("Poor", "#FF6D00", "🔶"),
    CRITICAL("Critical", "#FF1744", "🚨")
}

data class ParseResult(
    val success: Boolean,
    val record: BatteryRecord? = null,
    val errorMessage: String? = null
)
