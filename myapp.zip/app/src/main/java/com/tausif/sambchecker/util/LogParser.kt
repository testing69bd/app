package com.tausif.sambchecker.util

import android.content.Context
import android.net.Uri
import com.tausif.sambchecker.model.BatteryRecord
import com.tausif.sambchecker.model.ParseResult
import java.io.BufferedReader
import java.io.InputStreamReader

object LogParser {

    /**
     * Parse the dumpstate log file from URI
     * Extracts mSavedBatteryAsoc and other battery-related fields
     */
    fun parseFromUri(context: Context, uri: Uri, fileName: String): ParseResult {
        return try {
            val inputStream = context.contentResolver.openInputStream(uri)
                ?: return ParseResult(false, errorMessage = "Cannot open file")

            val reader = BufferedReader(InputStreamReader(inputStream))
            val content = StringBuilder()
            var line: String?
            while (reader.readLine().also { line = it } != null) {
                content.appendLine(line)
            }
            reader.close()
            inputStream.close()

            parseContent(content.toString(), fileName)
        } catch (e: Exception) {
            ParseResult(false, errorMessage = "Error reading file: ${e.message}")
        }
    }

    /**
     * Main parsing logic
     */
    private fun parseContent(content: String, fileName: String): ParseResult {
        // Extract device model from filename (e.g., dumpState_S916USQU6DYD9_202603030547.log)
        val deviceModel = extractDeviceModel(fileName)

        // REQUIRED: mSavedBatteryAsoc
        val batteryAsoc = extractIntValue(content, "mSavedBatteryAsoc")
            ?: return ParseResult(false, errorMessage =
                "Could not find 'mSavedBatteryAsoc' in log file.\n\n" +
                "Make sure you selected the correct dumpstate log file starting with 'dumpState_'")

        // OPTIONAL: Additional battery fields
        val additionalInfo = mutableMapOf<String, String>()

        extractStringValue(content, "mBatteryLevel")?.let { additionalInfo["Battery Level"] = "$it%" }
        extractStringValue(content, "mBatteryStatus")?.let { additionalInfo["Status"] = it }
        extractStringValue(content, "mBatteryHealth")?.let { additionalInfo["Hardware Health"] = it }
        extractStringValue(content, "mChargeType")?.let { additionalInfo["Charge Type"] = it }
        extractStringValue(content, "mWirelessCharging")?.let { additionalInfo["Wireless Charging"] = it }
        extractStringValue(content, "mBatteryCurrentNow")?.let {
            additionalInfo["Current Now"] = formatMicroAmps(it)
        }
        extractStringValue(content, "mBatteryVoltage")?.let {
            additionalInfo["Voltage"] = formatVoltage(it)
        }
        extractStringValue(content, "mBatteryTemperature")?.let {
            additionalInfo["Temperature"] = formatTemperature(it)
        }
        extractStringValue(content, "mBatteryCycleCount")?.let {
            additionalInfo["Cycle Count"] = it
        }
        extractStringValue(content, "mBatteryChargeCounter")?.let {
            additionalInfo["Charge Counter"] = "${it} mAh"
        }
        extractStringValue(content, "mBatteryFullCharge")?.let {
            additionalInfo["Full Charge Capacity"] = "${it} mAh"
        }
        extractStringValue(content, "mBatteryTechnology")?.let {
            additionalInfo["Technology"] = it
        }
        extractStringValue(content, "mBatteryPlugType")?.let {
            additionalInfo["Plug Type"] = it
        }

        // Raw capacity fields
        extractStringValue(content, "charge_full")?.let { additionalInfo["Design Charge Full"] = "$it μAh" }
        extractStringValue(content, "charge_full_design")?.let { additionalInfo["Design Full Capacity"] = "$it μAh" }
        extractStringValue(content, "capacity")?.let { additionalInfo["Raw Capacity"] = "$it%" }

        val record = BatteryRecord(
            batteryHealth = batteryAsoc,
            deviceModel = deviceModel,
            dumpFileName = fileName,
            additionalInfo = additionalInfo
        )

        return ParseResult(true, record)
    }

    private fun extractDeviceModel(fileName: String): String {
        // dumpState_S916USQU6DYD9_202603030547.log → S916USQU6DYD9
        return try {
            val parts = fileName.removePrefix("dumpState_").split("_")
            if (parts.size >= 2) parts[0] else "Unknown Samsung"
        } catch (e: Exception) {
            "Unknown Samsung"
        }
    }

    private fun extractIntValue(content: String, key: String): Int? {
        val patterns = listOf(
            Regex("$key\\s+(\\d+)"),
            Regex("$key=(\\d+)"),
            Regex("$key:\\s*(\\d+)")
        )
        for (pattern in patterns) {
            val match = pattern.find(content)
            if (match != null) {
                return match.groupValues[1].toIntOrNull()
            }
        }
        return null
    }

    private fun extractStringValue(content: String, key: String): String? {
        val patterns = listOf(
            Regex("$key\\s+([^\\s\\n]+)"),
            Regex("$key=([^\\s\\n]+)"),
            Regex("$key:\\s*([^\\s\\n]+)")
        )
        for (pattern in patterns) {
            val match = pattern.find(content)
            if (match != null) {
                val value = match.groupValues[1].trim()
                if (value.isNotEmpty() && value != "null" && value != "0") return value
            }
        }
        return null
    }

    private fun formatMicroAmps(value: String): String {
        val ma = value.toLongOrNull() ?: return "$value μA"
        return if (ma > 1000) "${ma / 1000} mA" else "$ma μA"
    }

    private fun formatVoltage(value: String): String {
        val mv = value.toLongOrNull() ?: return "$value mV"
        return "${mv} mV (${String.format("%.2f", mv / 1000.0)} V)"
    }

    private fun formatTemperature(value: String): String {
        val temp = value.toDoubleOrNull() ?: return "$value"
        val celsius = temp / 10.0
        return "%.1f°C / %.1f°F".format(celsius, celsius * 9 / 5 + 32)
    }
}
