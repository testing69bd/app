package com.tausif.sambchecker

import android.Manifest
import android.animation.ValueAnimator
import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.OpenableColumns
import android.view.View
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.tausif.sambchecker.databinding.ActivityMainBinding
import com.tausif.sambchecker.util.HistoryManager
import com.tausif.sambchecker.util.LogParser

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    private val filePickerLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            result.data?.data?.let { uri ->
                handleSelectedFile(uri)
            }
        }
    }

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        if (permissions.values.all { it }) {
            openFilePicker()
        } else {
            showPermissionDeniedDialog()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupUI()
        setupClickListeners()
        animateStepsIn()
        showLastResultBanner()
    }

    private fun setupUI() {
        // Step numbers are set in XML; we animate them counting up
        val stepViews = listOf(
            binding.tvStep1Num, binding.tvStep2Num, binding.tvStep3Num,
            binding.tvStep4Num, binding.tvStep5Num
        )
        stepViews.forEachIndexed { index, textView ->
            val target = index + 1
            textView.text = "0"
            val anim = ValueAnimator.ofInt(0, target).apply {
                duration = 500
                startDelay = (index * 150 + 400).toLong()
                addUpdateListener { textView.text = it.animatedValue.toString() }
            }
            anim.start()
        }
    }

    private fun setupClickListeners() {
        // Primary CTA: Select Log File
        binding.btnSelectFile.setOnClickListener {
            it.animate().scaleX(0.95f).scaleY(0.95f).setDuration(100).withEndAction {
                it.animate().scaleX(1f).scaleY(1f).setDuration(100).start()
            }.start()
            checkPermissionsAndOpenFile()
        }

        // Navigation footer buttons
        binding.btnHistory.setOnClickListener {
            startActivity(Intent(this, HistoryActivity::class.java))
            overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left)
        }

        // Social links
        binding.ivGithub.setOnClickListener { openUrl("https://github.com/tausifzaman") }
        binding.ivFacebook.setOnClickListener { openUrl("https://facebook.com/tausif.zaman.official") }
        binding.ivInstagram.setOnClickListener { openUrl("https://instagram.com/_tausif_zaman") }
        binding.ivTelegram.setOnClickListener { openUrl("https://t.me/tausifzaman0") }
        binding.tvWebsite.setOnClickListener { openUrl("https://tausifzaman.online") }

        // Info button
        binding.btnInfo.setOnClickListener { showHelpDialog() }

        // Dial pad shortcut hint
        binding.cardDialTip.setOnClickListener { showDialpadDialog() }
    }

    private fun animateStepsIn() {
        val steps = listOf(
            binding.cardStep1, binding.cardStep2, binding.cardStep3,
            binding.cardStep4, binding.cardStep5
        )
        steps.forEachIndexed { index, card ->
            card.alpha = 0f
            card.translationX = -80f
            card.animate()
                .alpha(1f)
                .translationX(0f)
                .setDuration(500)
                .setStartDelay((index * 120 + 300).toLong())
                .setInterpolator(android.view.animation.DecelerateInterpolator(2f))
                .start()
        }

        // Animate the select button
        binding.btnSelectFile.apply {
            alpha = 0f
            scaleX = 0.8f
            scaleY = 0.8f
            animate()
                .alpha(1f)
                .scaleX(1f)
                .scaleY(1f)
                .setDuration(500)
                .setStartDelay(900)
                .start()
        }
    }

    private fun showLastResultBanner() {
        val last = HistoryManager.getLastRecord(this) ?: return
        binding.cardLastResult.visibility = View.VISIBLE
        binding.tvLastHealth.text = "${last.batteryHealth}%"
        binding.tvLastDate.text = "Last checked: ${last.getFormattedDate()}"
        binding.tvLastDevice.text = last.deviceModel

        // Color the health value
        val color = getHealthColor(last.batteryHealth)
        binding.tvLastHealth.setTextColor(color)

        binding.cardLastResult.setOnClickListener {
            val intent = Intent(this, BatteryResultActivity::class.java)
            intent.putExtra(BatteryResultActivity.EXTRA_RECORD_ID, last.id)
            startActivity(intent)
        }
    }

    private fun checkPermissionsAndOpenFile() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            openFilePicker() // Android 13+ uses SAF directly
        } else {
            val perm = Manifest.permission.READ_EXTERNAL_STORAGE
            if (ContextCompat.checkSelfPermission(this, perm) == PackageManager.PERMISSION_GRANTED) {
                openFilePicker()
            } else {
                permissionLauncher.launch(arrayOf(perm))
            }
        }
    }

    private fun openFilePicker() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("text/plain", "application/octet-stream", "*/*"))
        }
        try {
            filePickerLauncher.launch(intent)
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(this, "No file manager found", Toast.LENGTH_SHORT).show()
        }
    }

    private fun handleSelectedFile(uri: Uri) {
        val fileName = getFileName(uri)

        // Validate file name
        if (!fileName.startsWith("dumpState_")) {
            showWrongFileDialog(fileName)
            return
        }

        // Show parsing indicator
        showParsingState(true)

        // Parse in background
        Thread {
            val result = LogParser.parseFromUri(this, uri, fileName)
            runOnUiThread {
                showParsingState(false)
                if (result.success && result.record != null) {
                    // Save to history
                    HistoryManager.saveRecord(this, result.record)
                    // Navigate to results
                    val intent = Intent(this, BatteryResultActivity::class.java)
                    intent.putExtra(BatteryResultActivity.EXTRA_RECORD_ID, result.record.id)
                    startActivity(intent)
                    overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left)
                } else {
                    showParseErrorDialog(result.errorMessage ?: "Unknown error")
                }
            }
        }.start()
    }

    private fun showParsingState(parsing: Boolean) {
        if (parsing) {
            binding.btnSelectFile.text = "Analyzing log..."
            binding.btnSelectFile.isEnabled = false
            binding.progressParsing.visibility = View.VISIBLE
        } else {
            binding.btnSelectFile.text = "📂  Select Log File"
            binding.btnSelectFile.isEnabled = true
            binding.progressParsing.visibility = View.GONE
        }
    }

    private fun getFileName(uri: Uri): String {
        var name = "unknown"
        val cursor = contentResolver.query(uri, null, null, null, null)
        cursor?.use {
            if (it.moveToFirst()) {
                val colIndex = it.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (colIndex >= 0) name = it.getString(colIndex)
            }
        }
        return name
    }

    private fun getHealthColor(health: Int): Int {
        return when {
            health >= 80 -> ContextCompat.getColor(this, R.color.health_excellent)
            health >= 60 -> ContextCompat.getColor(this, R.color.health_good)
            health >= 40 -> ContextCompat.getColor(this, R.color.health_fair)
            health >= 20 -> ContextCompat.getColor(this, R.color.health_poor)
            else -> ContextCompat.getColor(this, R.color.health_critical)
        }
    }

    private fun showHelpDialog() {
        AlertDialog.Builder(this, R.style.SamDialog)
            .setTitle("ℹ️ How It Works")
            .setMessage("""
                This app reads Samsung's diagnostic logs to check your battery's actual health percentage.

                The key value is: mSavedBatteryAsoc
                
                • 80-100% = Excellent battery health
                • 60-79%  = Good, normal aging
                • 40-59%  = Fair, consider monitoring
                • 20-39%  = Poor, may need replacement
                • 0-19%   = Critical, replace soon
                
                Note: This works on Samsung Galaxy devices running One UI.
            """.trimIndent())
            .setPositiveButton("Got it", null)
            .show()
    }

    private fun showDialpadDialog() {
        AlertDialog.Builder(this, R.style.SamDialog)
            .setTitle("📞 Dialpad Shortcut")
            .setMessage("Open your Phone/Dialpad app and type:\n\n*#9900#\n\nThis opens Samsung SysDump where you can run the diagnostic.")
            .setPositiveButton("Open Dialer") { _, _ ->
                try {
                    val intent = Intent(Intent.ACTION_DIAL).apply {
                        data = Uri.parse("tel:*%239900%23")
                    }
                    startActivity(intent)
                } catch (e: Exception) {
                    Toast.makeText(this, "Cannot open dialer", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showWrongFileDialog(fileName: String) {
        AlertDialog.Builder(this, R.style.SamDialog)
            .setTitle("⚠️ Wrong File")
            .setMessage("Selected: $fileName\n\nPlease select a file that starts with 'dumpState_'\n\nLocation: /sdcard/log/ or /storage/emulated/0/log/")
            .setPositiveButton("Try Again") { _, _ -> checkPermissionsAndOpenFile() }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showParseErrorDialog(error: String) {
        AlertDialog.Builder(this, R.style.SamDialog)
            .setTitle("❌ Parse Failed")
            .setMessage(error)
            .setPositiveButton("Try Again") { _, _ -> checkPermissionsAndOpenFile() }
            .setNegativeButton("Close", null)
            .show()
    }

    private fun showPermissionDeniedDialog() {
        AlertDialog.Builder(this, R.style.SamDialog)
            .setTitle("Permission Required")
            .setMessage("Storage permission is needed to read the log file. Please grant it in Settings.")
            .setPositiveButton("Settings") { _, _ ->
                startActivity(Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                    data = Uri.fromParts("package", packageName, null)
                })
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun openUrl(url: String) {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        } catch (e: Exception) {
            Toast.makeText(this, "Cannot open browser", Toast.LENGTH_SHORT).show()
        }
    }
}
