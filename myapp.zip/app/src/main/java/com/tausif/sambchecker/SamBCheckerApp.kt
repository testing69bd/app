package com.tausif.sambchecker

import android.app.Application
import android.content.pm.PackageManager
import android.os.Build
import android.util.Base64
import com.tausif.sambchecker.security.TamperDetector

class SamBCheckerApp : Application() {

    override fun onCreate() {
        super.onCreate()
        // Initialize tamper detection
        TamperDetector.init(this)
    }
}
