package com.tausif.sambchecker

import android.animation.ValueAnimator
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.view.animation.AccelerateDecelerateInterpolator
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.tausif.sambchecker.databinding.ActivityBatteryResultBinding
import com.tausif.sambchecker.model.BatteryRecord
import com.tausif.sambchecker.model.HealthStatus
import com.tausif.sambchecker.util.HistoryManager

class BatteryResultActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_RECORD_ID = "extra_record_id"
    }

    private lateinit var binding: ActivityBatteryResultBinding
    private var record: BatteryRecord? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityBatteryResultBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val recordId = intent.getLongExtra(EXTRA_RECORD_ID, -1L)
        record = HistoryManager.getRecords(this).find { it.id == recordId }
            ?: HistoryManager.getLastRecord(this)

        record?.let { displayResult(it) } ?: finish()

        setupClickListeners()
    }

    private fun displayResult(r: BatteryRecord) {
        val status = r.getHealthStatus()
        val healthColor = getHealthColorInt(r.batteryHealth)

        // Header
        binding.tvDeviceModel.text = r.deviceModel
        binding.tvCheckDate.text = r.getFormattedDate()

        // Status badge
        binding.tvHealthStatus.text = status.label
        binding.tvHealthEmoji.text = status.emoji

        // Animated percentage counter
        animateCounter(r.batteryHealth)

        // Circular progress
        animateCircularProgress(r.batteryHealth, healthColor)

        // Status card background tint
        binding.cardHealthBadge.setCardBackgroundColor(
            Color.parseColor(status.colorResId + "33") // 20% opacity
        )
        binding.tvHealthStatus.setTextColor(Color.parseColor(status.colorResId))

        // Health advice
        binding.tvAdvice.text = getHealthAdvice(r.batteryHealth)
        binding.tvAdviceTitle.text = getAdviceTitle(r.batteryHealth)

        // Previous check comparison
        showComparison(r)

        // Additional info
        displayAdditionalInfo(r)

        // File name
        binding.tvFileName.text = "📄 ${r.dumpFileName}"

        // Animate cards in sequence
        animateCardsIn()
    }

    private fun animateCounter(target: Int) {
        val animator = ValueAnimator.ofInt(0, target).apply {
            duration = 2000
            startDelay = 400
            interpolator = DecelerateInterpolator(2f)
            addUpdateListener { anim ->
                binding.tvPercentage.text = "${anim.animatedValue}"
            }
        }
        animator.start()
    }

    private fun animateCircularProgress(target: Int, color: Int) {
        binding.progressCircle.setIndicatorColor(color)
        binding.progressCircle.trackColor = Color.parseColor("#1A1A2E")

        val animator = ValueAnimator.ofInt(0, target).apply {
            duration = 2000
            startDelay = 400
            interpolator = DecelerateInterpolator(2f)
            addUpdateListener { anim ->
                binding.progressCircle.progress = anim.animatedValue as Int
            }
        }
        animator.start()
    }

    private fun showComparison(current: BatteryRecord) {
        val records = HistoryManager.getRecords(this)
        // Find previous record (not the current one)
        val previous = records.firstOrNull { it.id != current.id }

        if (previous != null) {
            binding.cardComparison.visibility = View.VISIBLE
            val diff = current.batteryHealth - previous.batteryHealth
            binding.tvPreviousHealth.text = "${previous.batteryHealth}%"
            binding.tvPreviousDate.text = previous.getFormattedDate()

            if (diff > 0) {
                binding.tvDiff.text = "+$diff%"
                binding.tvDiff.setTextColor(ContextCompat.getColor(this, R.color.health_excellent))
                binding.tvDiffLabel.text = "Improvement ↑"
            } else if (diff < 0) {
                binding.tvDiff.text = "$diff%"
                binding.tvDiff.setTextColor(ContextCompat.getColor(this, R.color.health_critical))
                binding.tvDiffLabel.text = "Degraded ↓"
            } else {
                binding.tvDiff.text = "No change"
                binding.tvDiff.setTextColor(ContextCompat.getColor(this, R.color.text_secondary))
                binding.tvDiffLabel.text = "Stable →"
            }
        } else {
            binding.cardComparison.visibility = View.GONE
        }
    }

    private fun displayAdditionalInfo(r: BatteryRecord) {
        val info = r.additionalInfo
        if (info.isEmpty()) {
            binding.cardAdditional.visibility = View.GONE
            return
        }
        binding.cardAdditional.visibility = View.VISIBLE

        val sb = StringBuilder()
        info.forEach { (key, value) ->
            sb.appendLine("$key:  $value")
        }
        binding.tvAdditionalInfo.text = sb.toString().trim()
    }

    private fun animateCardsIn() {
        val cards = listOf(
            binding.cardMainResult,
            binding.cardHealthBadge,
            binding.cardAdvice,
            binding.cardComparison,
            binding.cardAdditional,
            binding.cardFileInfo
        )
        cards.forEachIndexed { index, card ->
            if (card.visibility == View.GONE) return@forEachIndexed
            card.alpha = 0f
            card.translationY = 50f
            card.animate()
                .alpha(1f)
                .translationY(0f)
                .setDuration(500)
                .setStartDelay((index * 120 + 200).toLong())
                .setInterpolator(DecelerateInterpolator(2f))
                .start()
        }
    }

    private fun setupClickListeners() {
        binding.btnBack.setOnClickListener { onBackPressedDispatcher.onBackPressed() }
        binding.btnCheckAgain.setOnClickListener {
            startActivity(Intent(this, MainActivity::class.java))
            overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right)
            finish()
        }
        binding.btnHistory.setOnClickListener {
            startActivity(Intent(this, HistoryActivity::class.java))
            overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left)
        }

        // Share result
        binding.btnShare.setOnClickListener {
            record?.let { r ->
                val shareText = """
                    📱 Samsung Battery Life Check
                    ═══════════════════════
                    Device: ${r.deviceModel}
                    Battery Health: ${r.batteryHealth}%
                    Status: ${r.getHealthStatus().label} ${r.getHealthStatus().emoji}
                    Date: ${r.getFormattedDate()}
                    ═══════════════════════
                    Checked with Samsung Battery Life Checker
                    by Tausif Zaman | tausifzaman.online
                """.trimIndent()

                startActivity(Intent.createChooser(
                    Intent(Intent.ACTION_SEND).apply {
                        type = "text/plain"
                        putExtra(Intent.EXTRA_TEXT, shareText)
                    },
                    "Share Battery Health"
                ))
            }
        }

        // Social links in footer
        binding.tvWebsiteResult.setOnClickListener { openUrl("https://tausifzaman.online") }
    }

    private fun getHealthAdvice(health: Int): String {
        return when {
            health >= 80 -> "Your battery is in excellent condition! It holds most of its original capacity. Continue normal usage and avoid extreme temperatures to maintain this health."
            health >= 60 -> "Your battery has normal wear for its age. It's still performing well. Keep it between 20-80% charge when possible to extend its life."
            health >= 40 -> "Your battery is showing moderate degradation. You may notice shorter usage time. Consider reducing screen brightness and background apps to compensate."
            health >= 20 -> "Your battery health is poor. Battery life will be noticeably shorter. We recommend getting a battery replacement soon at an authorized Samsung service center."
            else -> "Your battery is critically degraded and should be replaced immediately. This can cause unexpected shutdowns and may damage your device over time."
        }
    }

    private fun getAdviceTitle(health: Int): String {
        return when {
            health >= 80 -> "💚 Great Shape!"
            health >= 60 -> "👍 Normal Aging"
            health >= 40 -> "⚠️ Monitor Closely"
            health >= 20 -> "🔶 Replace Soon"
            else -> "🚨 Replace Immediately"
        }
    }

    private fun getHealthColorInt(health: Int): Int {
        return when {
            health >= 80 -> ContextCompat.getColor(this, R.color.health_excellent)
            health >= 60 -> ContextCompat.getColor(this, R.color.health_good)
            health >= 40 -> ContextCompat.getColor(this, R.color.health_fair)
            health >= 20 -> ContextCompat.getColor(this, R.color.health_poor)
            else -> ContextCompat.getColor(this, R.color.health_critical)
        }
    }

    private fun openUrl(url: String) {
        try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) } catch (e: Exception) {}
    }

    override fun finish() {
        super.finish()
        overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right)
    }
}
