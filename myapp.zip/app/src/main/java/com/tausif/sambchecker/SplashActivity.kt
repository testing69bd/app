package com.tausif.sambchecker

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.AnimatorSet
import android.animation.ObjectAnimator
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.view.animation.AccelerateDecelerateInterpolator
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import androidx.appcompat.app.AppCompatActivity
import androidx.core.animation.doOnEnd
import com.tausif.sambchecker.databinding.ActivitySplashBinding

class SplashActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySplashBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySplashBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Hide system UI for immersive splash
        window.decorView.systemUiVisibility = (
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
        )

        startSplashAnimation()
    }

    private fun startSplashAnimation() {
        // Initial state: everything invisible/scaled down
        binding.ivBatteryIcon.apply {
            alpha = 0f
            scaleX = 0.3f
            scaleY = 0.3f
        }
        binding.tvAppName.apply {
            alpha = 0f
            translationY = 60f
        }
        binding.tvTagline.apply {
            alpha = 0f
            translationY = 40f
        }
        binding.tvMadeBy.apply {
            alpha = 0f
            translationY = 20f
        }
        binding.progressBar.alpha = 0f
        binding.lottieWave.alpha = 0f

        // Step 1: Battery icon appears with bounce
        val iconAnimX = ObjectAnimator.ofFloat(binding.ivBatteryIcon, "scaleX", 0.3f, 1.1f, 1.0f)
        val iconAnimY = ObjectAnimator.ofFloat(binding.ivBatteryIcon, "scaleY", 0.3f, 1.1f, 1.0f)
        val iconFade = ObjectAnimator.ofFloat(binding.ivBatteryIcon, "alpha", 0f, 1f)
        iconAnimX.duration = 700
        iconAnimY.duration = 700
        iconFade.duration = 400
        iconAnimX.interpolator = OvershootInterpolator(2.5f)
        iconAnimY.interpolator = OvershootInterpolator(2.5f)

        val iconSet = AnimatorSet().apply {
            playTogether(iconAnimX, iconAnimY, iconFade)
            startDelay = 200
        }

        // Step 2: Wave background
        val waveFade = ObjectAnimator.ofFloat(binding.lottieWave, "alpha", 0f, 0.6f).apply {
            duration = 600
            startDelay = 300
        }

        // Step 3: App name slides up
        val nameSlide = ObjectAnimator.ofFloat(binding.tvAppName, "translationY", 60f, 0f).apply {
            duration = 600
            interpolator = DecelerateInterpolator(2f)
        }
        val nameFade = ObjectAnimator.ofFloat(binding.tvAppName, "alpha", 0f, 1f).apply {
            duration = 600
        }
        val nameSet = AnimatorSet().apply {
            playTogether(nameSlide, nameFade)
            startDelay = 700
        }

        // Step 4: Tagline
        val tagSlide = ObjectAnimator.ofFloat(binding.tvTagline, "translationY", 40f, 0f).apply {
            duration = 500
            interpolator = DecelerateInterpolator()
        }
        val tagFade = ObjectAnimator.ofFloat(binding.tvTagline, "alpha", 0f, 1f).apply {
            duration = 500
        }
        val tagSet = AnimatorSet().apply {
            playTogether(tagSlide, tagFade)
            startDelay = 950
        }

        // Step 5: Progress and credits
        val progressFade = ObjectAnimator.ofFloat(binding.progressBar, "alpha", 0f, 1f).apply {
            duration = 400
            startDelay = 1200
        }
        val creditsFade = ObjectAnimator.ofFloat(binding.tvMadeBy, "alpha", 0f, 1f).apply {
            duration = 400
            startDelay = 1300
        }
        val creditsSlide = ObjectAnimator.ofFloat(binding.tvMadeBy, "translationY", 20f, 0f).apply {
            duration = 400
            startDelay = 1300
        }

        // Play all
        AnimatorSet().apply {
            playTogether(iconSet, waveFade, nameSet, tagSet, progressFade, creditsFade, creditsSlide)
            start()
        }

        // Navigate after delay
        binding.root.postDelayed({
            navigateToMain()
        }, 3000)
    }

    private fun navigateToMain() {
        val fadeOut = ObjectAnimator.ofFloat(binding.root, "alpha", 1f, 0f).apply {
            duration = 400
        }
        fadeOut.doOnEnd {
            startActivity(Intent(this, MainActivity::class.java))
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
            finish()
        }
        fadeOut.start()
    }
}
