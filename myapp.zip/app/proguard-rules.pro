# ============================================================
# Samsung Battery Life Checker - Maximum ProGuard Protection
# Made by Tausif Zaman | tausifzaman.online
# ============================================================

# === AGGRESSIVE OBFUSCATION ===
-optimizationpasses 7
-allowaccessmodification
-mergeinterfacesaggressively
-overloadaggressively
-repackageclasses ''
-flattenpackagehierarchy ''

# Use aggressive optimization
-optimizations !code/simplification/arithmetic,!code/simplification/cast,!field/*,!class/merging/*,code/simplification/*,code/removal/*,code/allocation/*

# === RENAME EVERYTHING ===
-obfuscationdictionary proguard-dict.txt
-classobfuscationdictionary proguard-dict.txt
-packageobfuscationdictionary proguard-dict.txt

# === REMOVE LOGGING (security) ===
-assumenosideeffects class android.util.Log {
    public static boolean isLoggable(java.lang.String, int);
    public static int v(...);
    public static int i(...);
    public static int w(...);
    public static int d(...);
    public static int e(...);
    public static int wtf(...);
}
-assumenosideeffects class java.io.PrintStream {
    public void println(...);
    public void print(...);
}

# === KEEP APPLICATION ENTRY POINTS ===
-keep class com.tausif.sambchecker.SplashActivity { *; }
-keep class com.tausif.sambchecker.MainActivity { *; }
-keep class com.tausif.sambchecker.BatteryResultActivity { *; }
-keep class com.tausif.sambchecker.HistoryActivity { *; }
-keep class com.tausif.sambchecker.SecurityManager { *; }

# Keep Application class
-keep public class * extends android.app.Application
-keep public class * extends android.app.Activity
-keep public class * extends android.app.Service
-keep public class * extends android.content.BroadcastReceiver

# === SECURITY: Keep tamper detection ===
-keep class com.tausif.sambchecker.security.** { *; }

# === DATA CLASSES (needed for Gson) ===
-keep class com.tausif.sambchecker.model.** { *; }
-keepclassmembers class com.tausif.sambchecker.model.** { *; }

# === KEEP ANDROID FRAMEWORK ===
-keepclassmembers class * extends android.content.Context {
   public void *(android.view.View);
   public void *(android.view.MenuItem);
}
-keepclassmembers class * implements android.os.Parcelable {
    static ** CREATOR;
}
-keepclassmembers enum * {
    public static **[] values();
    public static ** valueOf(java.lang.String);
}

# Keep View constructors
-keepclasseswithmembernames class * {
    native <methods>;
}
-keepclasseswithmembers class * {
    public <init>(android.content.Context, android.util.AttributeSet);
    public <init>(android.content.Context, android.util.AttributeSet, int);
}

# === LOTTIE ===
-keep class com.airbnb.lottie.** { *; }
-dontwarn com.airbnb.lottie.**

# === MPANDROIDCHART ===
-keep class com.github.mikephil.charting.** { *; }
-dontwarn com.github.mikephil.charting.**

# === MATERIAL COMPONENTS ===
-keep class com.google.android.material.** { *; }
-dontwarn com.google.android.material.**

# === KOTLIN ===
-keep class kotlin.** { *; }
-keep class kotlin.Metadata { *; }
-dontwarn kotlin.**
-keepclassmembers class **$WhenMappings { <fields>; }
-keepclassmembers class kotlin.Lazy { *; }

# === GSON ===
-keepattributes Signature
-keepattributes *Annotation*
-dontwarn sun.misc.**
-keep class com.google.gson.** { *; }
-keep class * implements com.google.gson.TypeAdapterFactory
-keep class * implements com.google.gson.JsonSerializer
-keep class * implements com.google.gson.JsonDeserializer

# === COROUTINES ===
-keepnames class kotlinx.coroutines.internal.MainDispatcherFactory {}
-keepnames class kotlinx.coroutines.CoroutineExceptionHandler {}
-keepclassmembers class kotlinx.coroutines.** { volatile <fields>; }

# === REMOVE STACK TRACE INFORMATION ===
-renamesourcefileattribute SourceFile
-keepattributes SourceFile,LineNumberTable

# === REFLECTION PROTECTION ===
-keepattributes InnerClasses
-keepattributes EnclosingMethod

# === PREVENT DECOMPILATION AIDS ===
-keepattributes !LocalVariableTable, !LocalVariableTypeTable

# === STRING ENCRYPTION HINT ===
# Strings are obfuscated via identifier renaming
# Add DexGuard or iXGuard for actual string encryption in production

# Suppress warnings
-dontwarn javax.annotation.**
-dontwarn org.conscrypt.**
-dontwarn org.bouncycastle.**
-dontwarn org.openjsse.**
