# Samsung Battery Life Checker
**by Tausif Zaman** | [tausifzaman.online](https://tausifzaman.online)

## 📱 App Overview
Reads Samsung's SysDump diagnostic logs to extract `mSavedBatteryAsoc` — the true battery health percentage that Samsung uses internally.

---

## 🚀 Setup Instructions

### Step 1: Import Project
1. Open Android Studio
2. `File → Open` → Select the `SamBChecker` folder
3. Wait for Gradle sync to complete

### Step 2: Add Fonts (REQUIRED)
Download **Inter** font from [fonts.google.com/specimen/Inter](https://fonts.google.com/specimen/Inter)
Place these files in `app/src/main/res/font/`:
- `inter_regular.ttf` (Regular, weight 400)
- `inter_bold.ttf` (Bold, weight 700)

**OR** (Quick fix) — replace all font references in XML layouts:
- Change `@font/inter_bold` → `sans-serif-medium`
- Change `@font/inter_regular` → `sans-serif`

### Step 3: Add Lottie Animation (Optional)
The splash screen uses a Lottie wave animation. You can:
- Download a free wave animation from [lottiefiles.com](https://lottiefiles.com)
- Name it `wave_animation.json` and place in `app/src/main/res/raw/`
- Or delete the `lottieWave` view from `activity_splash.xml`

### Step 4: Build & Run
- Connect your Samsung device or use an emulator
- Click `Run` (or Shift+F10)
- For release APK: `Build → Generate Signed Bundle/APK`

---

## 🔐 APK Protection Setup

### After First Release Build:
1. Run the app in debug mode
2. Add this temp code to get your signature hash:
```kotlin
// In SplashActivity.onCreate(), temporarily add:
val hash = TamperDetector.getCurrentSignatureHash(this)
Log.d("SIGNATURE", hash)
android.widget.Toast.makeText(this, hash, android.widget.Toast.LENGTH_LONG).show()
```
3. Copy the printed hash
4. Set it as `EXPECTED_SIGNATURE_HASH` in `TamperDetector.kt`
5. Uncomment the signature check line in `TamperDetector.runChecks()`
6. Remove the temp debug code
7. Rebuild release APK

### Protection Layers Included:
| Protection | Status |
|------------|--------|
| Code Obfuscation (R8/ProGuard) | ✅ Enabled in release |
| Package name verification | ✅ Active |
| Debug build detection | ✅ Active |
| Emulator detection | ✅ Active (disabled in debug) |
| Log stripping | ✅ All logs removed in release |
| Network security (HTTPS only) | ✅ Active |
| Backup disabled | ✅ Active |
| String obfuscation | ⚠️ Via ProGuard renaming |
| Signature verification | ⚠️ Enable after first build |
| Root detection | ⚠️ Uncomment in TamperDetector |

### For Maximum Protection (Advanced):
Consider adding **DexGuard** or **iXGuard** (commercial) for:
- True string encryption
- RASP (Runtime Application Self-Protection)
- Anti-hooking protection

---

## 📁 Project Structure
```
SamBChecker/
├── app/src/main/
│   ├── java/com/tausif/sambchecker/
│   │   ├── SamBCheckerApp.kt          — Application class
│   │   ├── SplashActivity.kt          — Animated splash screen
│   │   ├── MainActivity.kt            — Step guide + file picker
│   │   ├── BatteryResultActivity.kt   — Results display
│   │   ├── HistoryActivity.kt         — Check history
│   │   ├── model/BatteryRecord.kt     — Data model
│   │   ├── util/LogParser.kt          — Log file parser
│   │   ├── util/HistoryManager.kt     — SharedPreferences storage
│   │   └── security/TamperDetector.kt — APK protection
│   └── res/
│       ├── layout/                    — All XML layouts
│       ├── drawable/                  — Icons & backgrounds
│       ├── values/                    — Colors, themes, strings
│       ├── anim/                      — Transition animations
│       ├── font/                      — Inter font (add manually)
│       ├── raw/                       — Lottie animation JSON
│       └── xml/                       — Config files
├── build.gradle                       — App dependencies
├── proguard-rules.pro                 — Protection rules
└── README.md
```

---

## 🎨 Design System
- **Theme:** Dark navy (`#0A0E1A`) with Samsung blue accent (`#1DB7FF`)
- **Cards:** Elevated dark glass `#161D2F`
- **Health Colors:**
  - 🟢 80-100% = Excellent `#00E676`
  - 🟩 60-79%  = Good `#76FF03`  
  - 🟡 40-59%  = Fair `#FFAB00`
  - 🟠 20-39%  = Poor `#FF6D00`
  - 🔴 0-19%   = Critical `#FF1744`

---

## 👤 Credits
**Made with ❤️ by Tausif Zaman**
- 🌐 Website: [tausifzaman.online](https://tausifzaman.online)
- 🐙 GitHub: [@tausifzaman](https://github.com/tausifzaman)
- 📘 Facebook: [@tausif.zaman.official](https://facebook.com/tausif.zaman.official)
- 📷 Instagram: [@_tausif_zaman](https://instagram.com/_tausif_zaman)
- ✈️ Telegram: [@tausifzaman0](https://t.me/tausifzaman0)
